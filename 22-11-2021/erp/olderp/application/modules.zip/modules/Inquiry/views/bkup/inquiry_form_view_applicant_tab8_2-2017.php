<div class="tab-pane tab-space" id="tab_1_1_3">
                        <div class="portlet-body">
                        <?php //**************************** Education Start ************************** ?>
                            <div id="meedu_ajax_main">
                            </div>
                        <?php //**************************** Education End ************************** ?>
                        <?php //**************************** Experience Start ************************** ?>
                            <div id="meexp_ajax_main">
                            </div>
                        <?php //**************************** Experience End ************************** ?>
                        <?php //************************************ Language start **************************** ?>
                            <div id="melang_ajax_main">
                            </div>
                        <?php //************************************ Language End **************************** ?>
                        <?php //************************************ Relative start **************************** ?>
                          <div id="merel_ajax_main">
                          </div>
                        <?php //************************************ Relative End **************************** ?>     
                                <h3>Refusal Details</h3>
                                <hr />
                                <div class="row">
                                        <div class="col-md-4">
                                              <div class="form-group">
                                                     <label class="control-label col-md-3">Country</label>
                                                       <div class="col-md-9">
                                                        <select id="spo_rcont" name="spo_rcont" class="form-control" data-placeholder="Choose Country" tabindex="8">
                                                           <option value="Category 1">India</option>
                                                           <option value="Category 2">US</option>
                                                           <option value="Category 3">UK</option>
                                                           <option value="Category 4">Canada</option>
                                                        </select>
                                                       </div>
                                              </div>
                                            </div>  
                                            <div class="col-md-3">
                                                <div class="form-group"> 
                                                <label class="control-label col-md-4">Date</label>
                                                    <div class="col-md-8">
                                                        <input class="form-control form-control-inline input-medium date-picker" size="16" type="text" value="" id="o_rdate" name="o_rdate" data-date="12/20" data-date-format="mm/yy" tabindex="9"/>                               
                                                    </div>
                                                </div>
                                        </div>
                                        <div class="col-md-4">
                                              <div class="form-group">
                                                     <label class="control-label col-md-3">Category</label>
                                                       <div class="col-md-9">
                                                        <select id="spo_rcont" name="spo_rcont" class="form-control" data-placeholder="Choose Country" tabindex="8">
                                                           <option value="Category 1">Category 1</option>
                                                           <option value="Category 2">Category 2</option>
                                                           <option value="Category 3">Category 3</option>
                                                           <option value="Category 4">Category 4</option>
                                                        </select>
                                                       </div>
                                              </div>
                                            </div>
                                        </div>
                                <div class="row">   
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label class="control-label col-md-2">Remark :</label>
                                                    <div class="col-md-10">
                                                        <textarea class="form-control" rows="4" id="o_rremark" name="o_rremark" tabindex="10"></textarea>
                                                    </div>
                                            </div>
                                        </div>
                            </div>
                                <div class="row">
                                <div class="col-md-12">
                                    <a href="javascript:;" class="btn green button-submit" tabindex="5"> Add More
                                    <i class="fa fa-check"></i>
                                    </a>  
                                </div>
                            </div> 
                        </div>                   
                        <br />
                        <div class="form-actions">
                            <div class="row">
                                <div class="col-md-offset-5 col-md-7">
                                    <a href="javascript:;" class="btn default button-previous" style="display: inline-block;" tabindex="16" id="back-btn">
                                        <i class="fa fa-angle-left"></i> Back </a>
                                    <a href="javascript:;" class="btn btn-outline green button-next" tabindex=" 17" id="continue-btn"> Continue
                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                    <a href="javascript:;" class="btn green button-submit" style="display: none;"> Submit
                                        <i class="fa fa-check"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                       </div>